<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="regis.css">
	<title>Main Page</title>
</head>
<body>

	<div class="container">
		<div class="logo" style="margin-left: 115px; margin-bottom: 30px;">
			<img src="unpam.png">
		</div>

		<div>
			<h1 style="text-align: center; font-size: 20px; margin-bottom: 30px; margin-top: -20px;">
				Kelompok 3 <br>
				Muhammad Sadid Rabbani 221011402901 <br>
				Gusti Sulaiman Panbada 221011402706 <br>
				Maulana Adam Syafiq 221011402829
			</h1>
		</div>
		<div>
			<a href="index.php" class="btn btn-primary mt-2" style="margin-left: 218px;">NEXT</a>
		</div>
	</div>

</body>
</html>